export type Personaje ={
    id:number,
    nombre:string,
    imagen:string,
    estado:string

}