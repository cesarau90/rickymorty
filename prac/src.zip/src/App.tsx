import "./App.css"
import { Card } from "./components"
import { usePersona } from "./hooks"

function App() {
  const { personajes } = usePersona()

  console.log("personajes:", personajes)

  return (
    <div className="container">
      {personajes.map((p) => (
        <Card
          key={p.id}
          nombre={p.nombre}
          imagen={p.imagen}
          estado={p.estado}
        />
      ))}
    </div>
  )
}

export default App